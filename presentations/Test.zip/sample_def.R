require("pBrackets")
require("ragg")

agg_png("figures/sample_def_01.png", width = 3840, height = 2160, res = 384)

par(mar = c(0, 0, 0, 0), family = "sans")

cols <- rev(c("#1f78b4", "#a6cee3", "#33a02c"))

plot(NA, xlim = c(0.1, 0.9), ylim = c(0.1, 0.8), bty = "n", axes = FALSE)

polygon(x = c(1/4, 3/4, 3/4, 1/4, 1/4),
        y = c(1/3, 1/3, 4/9, 4/9, 1/3), border = NA, col = cols[1])
polygon(x = c(1/4, 3/4, 3/4, 1/4, 1/4),
        y = c(4/9, 4/9, 5/9, 5/9, 4/9), border = NA, col = cols[2])
polygon(x = c(1/4, 3/4, 3/4, 1/4, 1/4),
        y = c(5/9, 5/9, 2/3, 2/3, 5/9), border = NA, col = cols[3])

w <- 1/50
col <- "grey50"
segments(x0 = c(1/4, 5/12, 1/4), 
         y0 = c(1/3, 1/3, 2/3 + 5 * w), 
         x1 = c(5/12, 5/12, 1/4), 
         y1 = c(1/3, 2/3 + 2 * w, 1/3), col = col)

segments(x0 = c(5/12, 7/12), 
         y0 = c(1/3, 1/3), 
         x1 = c(7/12, 7/12), 
         y1 = c(1/3, 2/3 + 5 * w), col = col)

segments(x0 = c(7/12, 3/4), 
         y0 = c(1/3, 1/3), 
         x1 = c(3/4, 3/4), 
         y1 = c(1/3, 2/3 + 5 * w), col = col)

text(1/3, 2/3 + w, "Validation sample (OOS)", cex = 0.8)

text(1/2, 2/3 + w, "Development sample", cex = 0.8)

text(2/3, 2/3 + w, "Out-of-time sample (OOT)", cex = 0.8)

text(5/12, 2/3 + 4 * w, "INITIAL VALIDATION", col = "darkgrey")

text(2/3, 2/3 + 4 * w, "ANNUAL VALIDATION", col = "darkgrey")

text(1/2, 11/18, "With realized values at the end of the observation period",
     col = "white", font = 2, cex = 1)

text(1/2, 1/2, "Without realized values at the end of the observation period",
     col = "white", font = 2, cex = 1)

text(1/2, 7/18, "In default at the start of the observation period",
     col = "white", font = 2, cex = 1)

brackets(x1 = 1/4, y1 = 1/3 - w, x2 = 7/12, y2 = 1/3 - w, h = -w, lwd = 2, type = 1)

text(5/12, 1/3 - 4 * w, "In-time sample / overall sample")

brackets(x1 = 1/4, y1 = 1/3 - 7 * w, x2 = 3/4, y2 = 1/3 - 7 * w, h = -w, lwd = 2, type = 1)

text(1/2, 1/3 - 10 * w, "Overall application sample")

brackets(x1 = 3/4 + w, y1 = 2/3, x2 = 3/4 + w, y2 = 4/9, h = w, lwd = 2, type = 1)

text(3/4 + 3 * w, 5/9, "Back-testing /\nperforming sample", adj = 0)

invisible(dev.off())

###



agg_png("figures/sample_def_02.png", width = 3840, height = 2160, res = 384)

par(mar = c(0, 0, 0, 0), family = "sans")

cols <- rev(c("#1f78b4", "#a6cee3", "#33a02c"))

plot(NA, xlim = c(0.1, 0.9), ylim = c(0.1, 0.8), bty = "n", axes = FALSE)

polygon(x = c(1/4, 3/4, 3/4, 1/4, 1/4),
        y = c(1/3, 1/3, 1/2, 1/2, 1/3), border = NA, col = cols[3])
polygon(x = c(1/4, 3/4, 3/4, 1/4, 1/4),
        y = c(1/2, 1/2, 2/3, 2/3, 1/2), border = NA, col = cols[1])

w <- 1/50
col <- "grey50"
segments(x0 = c(1/4, 5/12, 1/4), 
         y0 = c(1/3, 1/3, 2/3 + 5 * w), 
         x1 = c(5/12, 5/12, 1/4), 
         y1 = c(1/3, 2/3 + 2 * w, 1/3), col = col)

segments(x0 = c(5/12, 7/12), 
         y0 = c(1/3, 1/3), 
         x1 = c(7/12, 7/12), 
         y1 = c(1/3, 2/3 + 5 * w), col = col)

segments(x0 = c(7/12, 3/4), 
         y0 = c(1/3, 1/3), 
         x1 = c(3/4, 3/4), 
         y1 = c(1/3, 2/3 + 5 * w), col = col)

text(1/3, 2/3 + w, "Validation sample (OOS)", cex = 0.8)

text(1/2, 2/3 + w, "Development sample", cex = 0.8)

text(2/3, 2/3 + w, "Out-of-time sample (OOT)", cex = 0.8)

text(5/12, 2/3 + 4 * w, "INITIAL VALIDATION", col = "darkgrey")

text(2/3, 2/3 + 4 * w, "ANNUAL VALIDATION", col = "darkgrey")

text(1/2, 21/36, "In default at the snapshot date",
     col = "white", font = 2, cex = 1)

text(1/2, 15/36, "Not in default at the snapshot date",
     col = "white", font = 2, cex = 1)

brackets(x1 = 1/4, y1 = 1/3 - w, x2 = 7/12, y2 = 1/3 - w, h = -w, lwd = 2, type = 1)

text(5/12, 1/3 - 4 * w, "In-time sample / overall sample")

brackets(x1 = 1/4, y1 = 1/3 - 7 * w, x2 = 3/4, y2 = 1/3 - 7 * w, h = -w, lwd = 2, type = 1)

text(1/2, 1/3 - 10 * w, "Overall application sample")

brackets(x1 = 3/4 + w, y1 = 2/3, x2 = 3/4 + w, y2 = 1/2, h = w, lwd = 2, type = 1)

text(3/4 + 3 * w, 7/12, "Back-testing /\nin-default sample", adj = 0)

invisible(dev.off())
