# Conditional formatting of rendered text
require("dplyr")
style_dp <- function(x) {
  color <- dplyr::case_when(
    x == "poor"        ~ "red",
    x == "moderate"    ~ "orange",
    x == "good"        ~ "green",
    TRUE                ~ "gray"
  )
  
  # HTML output
  if (knitr::is_html_output()) {
    sprintf("<strong><span style='color:%s'>%s</span></strong>", color, x)
    
    # PDF (LaTeX) output
  } else if (knitr::is_latex_output()) {
    sprintf("\\textbf{\\textcolor{%s}{%s}}", color, x)
    
    # Word and others — fallback to just bold
  } else {
    paste0("**", x, "**")
  }
}
