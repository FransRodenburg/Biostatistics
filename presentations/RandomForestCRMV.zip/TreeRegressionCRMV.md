Tree-Based Models
========================================================
author: Dr. F.J. Rodenburg
date: April 2024 (rev. 2)
autosize: true**
transition: none

<style>
.section .reveal .state-background{
  background-color: steelblue;
  background-size: cover;
}
.reveal h3 {
  font-size: 40px;
}
.small-code pre code {
  font-size: 1em;
}
.reveal section img { background:none; border:none; box-shadow:none; }
</style>



Tree-Based Models
========================================================

<small> Introduction:

1. What is *regression*?
2. What does it mean for a regression model to be *linear*?
3. Two examples of non-linear models (regression tree, random forest).

</small>

What is Regression?
========================================================

<small>*Regress* to a simpler explanation of the data-generating process.

![plot of chunk unnamed-chunk-1](figures/regress.png)

</small>

What is Regression?
========================================================
incremental: true

<small>*Regress* to a simpler explanation of the <b>data-generating process</b>.

![plot of chunk unnamed-chunk-2](figures/Model.png)

* Statistics: Understand and express the strength of evidence.
* Regression: Extract the <font color = #2D4680><b>systematic part</b></font> of a random process.

Inevitably, simplification means making errors.

> *All models are wrong, but some are useful...*

> *...the question you need to ask is not "Is the model true?" (it never is) but "Is the model good enough for this particular application?"* ---George Box
</small>

What is Linear Regression?
========================================================
incremental: true

<small>Modeling an outcome as a <font color = #3979A8><b>linear combination</b></font> of explanatory effects.

Matrix notation: $$\mathbf{y} = \color{steelblue}{X\boldsymbol\beta} + \boldsymbol\varepsilon$$

Which means: $$y_i = \color{steelblue}{\beta_0 + \sum_{j=1}^p \beta_j \cdot x_j} + \varepsilon_i$$

Which means:<br><br> $$\text{outcome} = \color{steelblue}{\text{intercept} + \text{slope}_1 \cdot x_1 + \text{slope}_2 \cdot x_2 + \dots} + \text{error}$$

</small>

Simple Linear Regression
========================================================

<small>Visualization of simple linear regression:



![plot of chunk unnamed-chunk-4](figures/ezgif-LM.gif)

</small>

Multiple Linear Regression
========================================================

<small>You can have slopes in multiple directions (i.e. multiple explanatory effects):



![plot of chunk unnamed-chunk-5](figures/twoslopes.png)

</font></small>

What is Linear Regression?
========================================================

<small>Modeling an outcome as a <font color = #3979A8><b>linear combination</b></font> of explanatory effects.

Matrix notation: $$\mathbf{y} = \color{steelblue}{X\boldsymbol\beta} + \boldsymbol\varepsilon$$

Which means: $$y_i = \color{steelblue}{\beta_0 + \sum_{j=1}^p \beta_j \cdot x_j} + \varepsilon_i$$

Which means:<br><br> $$\text{outcome} = \color{steelblue}{\text{intercept} + \text{slope}_1 \cdot x_1 + \text{slope}_2 \cdot x_2 + \dots} + \text{error}$$

<br><b>As long as the relationship with the outcome can be expressed in terms of **intercept** and **slope(s)**, the model is linear.</b>

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?



![plot of chunk unnamed-chunk-6](figures/StillLinear.png)

<font size = 5, color = "gray"><i>The estimated model is shown in the lower-right corner of each plot.</i>
</font></small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?



![plot of chunk unnamed-chunk-7](figures/StillLinear1.png)

$$\hat{y} = 35 + 5x$$

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?

![plot of chunk unnamed-chunk-8](figures/StillLinear1.png)

$$\hat{y} = 35 + 5x \\ \tiny\text{intercept} + \text{slope} \times \text{explanatory}$$

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?



![plot of chunk unnamed-chunk-9](figures/StillLinear2.png)

$$\hat{y} = 32 + 5\log(x)$$

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?

![plot of chunk unnamed-chunk-10](figures/StillLinear2.png)

$$\begin{aligned}\hat{y} &= 32 + 5\log(x) \\ &= 32 + 5z \end{aligned}$$

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?



![plot of chunk unnamed-chunk-11](figures/StillLinear3.png)

$$\hat{y} = 35 + 5x - 10x^2$$

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?

![plot of chunk unnamed-chunk-12](figures/StillLinear3.png)

$$\begin{aligned}\hat{y} &= 35 + 5x - 10x^2 \\ &= 35 + 5x - 10z \end{aligned}$$

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?



![plot of chunk unnamed-chunk-13](figures/StillLinear4.png)

$$\hat{y} = 35 + 5\sin(x)$$

</small>

Quiz
========================================================

<small>Which of the following <font color = #3979A8><b>models</b></font> are linear?

![plot of chunk unnamed-chunk-14](figures/StillLinear4.png)

$$\begin{aligned}\hat{y} &= 35 + 5\sin(x) \\ &= 35 + 5z \end{aligned}$$

</small>

Categorical Explanatory Variables
========================================================
incremental: true

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-15](figures/heightLM1.png)
</small>

Categorical Explanatory Variables
=========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-16](figures/heightLM2.png)
</small>

Categorical Explanatory Variables
=========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-17](figures/heightLM3.png)
</small>

Categorical Explanatory Variables
=========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-18](figures/heightLM3.png)
</small>


<small>
![plot of chunk unnamed-chunk-20](figures/HumanHeight1.png)
</small>

Categorical Explanatory Variables
========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-21](figures/heightLM3.png)
</small>


![plot of chunk unnamed-chunk-23](figures/HumanHeight2.png)
</small>

Categorical Explanatory Variables
========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-24](figures/heightLM3.png)
</small>


![plot of chunk unnamed-chunk-26](figures/HumanHeight3.png)
</small>

Categorical Explanatory Variables
========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-27](figures/heightLM3.png)
</small>


![plot of chunk unnamed-chunk-29](figures/HumanHeight4.png)
</small>

Categorical Explanatory Variables
========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-30](figures/heightLM3.png)
</small>


![plot of chunk unnamed-chunk-32](figures/HumanHeight5.png)
</small>

Categorical Explanatory Variables
========================================================

<small>Simple example: Adult human height in The Netherlands

![plot of chunk unnamed-chunk-33](figures/heightLM3.png)
</small>


![plot of chunk unnamed-chunk-35](figures/HumanHeight6.png)
</small>

(Almost) Everything is (Linear) Regression
========================================================

<small>Some of the most common techniques in the life sciences:

* <b>$T$-test</b>: <font size = 5>Linear model with 1 dummy variable;</font>
* <b>ANOVA</b>: <font size = 5>Linear model with multiple dummy variables;</font>
* <b>Simple linear regression</b>: <font size = 5>Linear model with 1 continuous explanatory variable;</font>
* <b>Multiple linear regression</b>: <font size = 5>Linear model with multiple explanatory variables;</font>
* <b>ANCOVA</b>: <font size = 5>Linear model with both continuous expl. variable(s) and dummy variable(s);</font>
* <b>GLM</b>: <font size = 5>Linear model with any probability distribution in the exponential dispersion family;</font>
* <b>Mixed model</b>: <font size = 5>Linear model with both fixed and random effects, to model dependency;</font>
* <b>GLMM</b>: <font size = 5>GLM + mixed model;</font>
* <b>GAM</b>: <font size = 5>When you need a probability distribution <b>not</b> in the exponential dispersion family;</font>
* <b>Mixed GAM</b>: <font size = 5>GAM + mixed model.</font>
* <b>Regularized linear models</b>: <font size = 5>Any of the above with regularization.</font>
* <b>Beta regression</b>: <font size = 5>A GLM-like model for values between 0 and 1.</font>
* <b>Survival analysis</b>: <font size = 5>Specialized GLM-like model for time until event data.</font>

</small>

Non-Linear Models
========================================================

<small>Of course, not everything is linear:

* <font color = "grey"><b>GAM</b>: When you need a different probability distribution than in GLMs;
* <b>Mixed GAM</b>: GAM + mixed model.
* <b>Regularized linear models</b>: Restricted parameter space.</font>
* <b>Random forest</b>: Easy to use, yet powerful predictive model;$^\dagger$
* <b>Neural network</b>: Not so easy to use, extremely versatile predictive model.$^\dagger$

<font size = 5, color = "gray">$\dagger$: *All* models can be used as predictive models. When I specifically refer to something a predictive model, I mean that it is usually harder to understand how it got to its conclusion, requires more observations than linear models, and is mainly useful for prediction.

</font></small>

Tree-Based Models
========================================================
incremental:true

<small>A class of models based on **recursive binary splitting**.

* Binary split<font color = "white">
* Recursive binary split

![plot of chunk unnamed-chunk-36](figures/binarysplit.png)

</font></small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Binary split
* Recursive binary split

![plot of chunk unnamed-chunk-37](figures/recursivebinarysplit.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-38](TreeRegressionCRMV-figure/unnamed-chunk-38-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-39](TreeRegressionCRMV-figure/unnamed-chunk-39-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-40](TreeRegressionCRMV-figure/unnamed-chunk-40-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-41](TreeRegressionCRMV-figure/unnamed-chunk-41-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-42](TreeRegressionCRMV-figure/unnamed-chunk-42-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-43](TreeRegressionCRMV-figure/unnamed-chunk-43-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-44](TreeRegressionCRMV-figure/unnamed-chunk-44-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-45](TreeRegressionCRMV-figure/unnamed-chunk-45-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

![plot of chunk unnamed-chunk-46](TreeRegressionCRMV-figure/unnamed-chunk-46-1.png)

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* How does that work?

<img src="TreeRegressionCRMV-figure/unnamed-chunk-47-1.png" alt="plot of chunk unnamed-chunk-47" width="1008px" />

</small>

Tree-Based Models
========================================================
incremental: true

<small>A class of models based on **recursive binary splitting**.

* What does that look like with more than 1 variable?

<img src="TreeRegressionCRMV-figure/unnamed-chunk-48-1.png" alt="plot of chunk unnamed-chunk-48" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* What about a categorical outcome (classification)?

<img src="TreeRegressionCRMV-figure/unnamed-chunk-49-1.png" alt="plot of chunk unnamed-chunk-49" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* ...or survival analysis?

<img src="TreeRegressionCRMV-figure/unnamed-chunk-50-1.png" alt="plot of chunk unnamed-chunk-50" width="1008px" />

</small>



Tree-Based Models
========================================================
incremental: true
class: small-code

<small>A class of models based on **recursive binary splitting**.

* In R, you can easily fit a tree-regression as follows:


```r
library("party")
TreeModel <- ctree(Sepal.Length ~ Species + Petal.Length, data = iris)         
```

* ...or a classification tree as follows:


```r
library("party")
TreeModel <- ctree(Species ~ Sepal.Length + Petal.Length, data = iris)         
```

* You can then view the tree with `print` or `plot`.

</small>

Tree-Based Models
========================================================
class: small-code

<small>A class of models based on **recursive binary splitting**.

* In R, you can easily fit a tree-regression as follows:


```r
library("party")
TreeModel <- ctree(Sepal.Length ~ Species + Petal.Length, data = iris)         
print(TreeModel)
```

```

	 Conditional inference tree with 5 terminal nodes

Response:  Sepal.Length 
Inputs:  Species, Petal.Length 
Number of observations:  150 

1) Petal.Length <= 4.2; criterion = 1, statistic = 113.233
  2) Petal.Length <= 3.3; criterion = 1, statistic = 31.511
    3)*  weights = 53 
  2) Petal.Length > 3.3
    4)*  weights = 20 
1) Petal.Length > 4.2
  5) Petal.Length <= 6; criterion = 1, statistic = 39.81
    6) Petal.Length <= 5.1; criterion = 1, statistic = 15.055
      7)*  weights = 43 
    6) Petal.Length > 5.1
      8)*  weights = 25 
  5) Petal.Length > 6
    9)*  weights = 9 
```


</small>

Tree-Based Models
========================================================
class: small-code

<small>A class of models based on **recursive binary splitting**.

* In R, you can easily fit a tree-regression as follows:


```r
library("party")
TreeModel <- ctree(Sepal.Length ~ Species + Petal.Length, data = iris)         
plot(TreeModel)
```

![plot of chunk unnamed-chunk-54](TreeRegressionCRMV-figure/unnamed-chunk-54-1.png)


</small>

Tree-Based Models
========================================================
incremental: true

<small>A class of models based on **recursive binary splitting**.

* A non-linear modelling approach
* Can be used for many different purposes
* Most common: Classification & regression trees (CART)
* Let's see how robust it is!

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-55-1.png" alt="plot of chunk unnamed-chunk-55" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-56-1.png" alt="plot of chunk unnamed-chunk-56" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-57-1.png" alt="plot of chunk unnamed-chunk-57" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-58-1.png" alt="plot of chunk unnamed-chunk-58" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-59-1.png" alt="plot of chunk unnamed-chunk-59" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-60-1.png" alt="plot of chunk unnamed-chunk-60" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-61-1.png" alt="plot of chunk unnamed-chunk-61" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-62-1.png" alt="plot of chunk unnamed-chunk-62" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-63-1.png" alt="plot of chunk unnamed-chunk-63" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-64-1.png" alt="plot of chunk unnamed-chunk-64" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-65-1.png" alt="plot of chunk unnamed-chunk-65" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-66-1.png" alt="plot of chunk unnamed-chunk-66" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-67-1.png" alt="plot of chunk unnamed-chunk-67" width="1008px" />

</small>

Tree-Based Models
========================================================

<small>A class of models based on **recursive binary splitting**.

* Let's see how robust it is!
* Regression tree fitted to 30 random observations from `iris`:

<img src="TreeRegressionCRMV-figure/unnamed-chunk-68-1.png" alt="plot of chunk unnamed-chunk-68" width="1008px" />

* Oh...

</small>

Tree-Based Models
========================================================
incremental: true

<small>A class of models based on **recursive binary splitting**.

* It turns out that this approach is incredibly unstable;
* A tree-based model is a **high-variance** estimator<br><font color = "grey"><i>(The model is very sensitive to changes in the data.)</i></font>
* This severely hampers their usefulness in practice...

...but we have computing power

* How about we just fit a tree to thousands of data sets?
* Each data set is a slightly altered version;
* We can 'slightly alter' the original data set through bootstrapping;
* The resulting thousands of predictions are combined;
* We end up with a low-variance estimator (stable, precise);
* This is called a **random forest**.

</small>

Random Forests
========================================================
incremental: true

<small>A model that combines tree-based models with **bootstrap aggregation**.

* Draw $n$ samples from the original sample *with replacement*.
* Example with an original sample size of $n = 5$:
    * 1, 2, 2, 4, 5
    * 2, 3, 4, 4, 5
    * 1, 2, 3, 3, 5
    * 1, 1, 2, 4, 4
    * 3, 4, 5, 5, 5
    * ...
* Repeat e.g., 1000 times
* You now have 1000 bootstrap samples
* **Fit a tree-model to each bootstrap sample**
* In case of regression: Average all 1000 predictions
* In case of classification: Cast a majority vote

</small>

Random Forests
========================================================
incremental: true

<small>Predicting an outcome with a random forest:

<img src="figures/rf0.png" alt="plot of chunk unnamed-chunk-69" width="1008px" />

</small>

Random Forests
========================================================

<small>Predicting an outcome with a random forest:

<img src="figures/rf1.png" alt="plot of chunk unnamed-chunk-70" width="1008px" />

</small>

Random Forests
========================================================

<small>Predicting an outcome with a random forest:

<img src="figures/rf2.png" alt="plot of chunk unnamed-chunk-71" width="1008px" />

</small>

Random Forests
========================================================

<small>Predicting an outcome with a random forest:

<img src="figures/rf3.png" alt="plot of chunk unnamed-chunk-72" width="1008px" />

</small>

Random Forests
========================================================

<small>Predicting an outcome with a random forest:

<img src="figures/rf4.png" alt="plot of chunk unnamed-chunk-73" width="1008px" />

</small>

Random Forests
========================================================

<small>Predicting an outcome with a random forest:

<img src="figures/rf5.png" alt="plot of chunk unnamed-chunk-74" width="1008px" />

</small>

Random Forests
========================================================
incremental: true

<small>A model that combines tree-based models with **bootstrap aggregation**.

* This happens to be one of the most powerful predictive models there is;
* Mainly because:
    * It is a non-linear model, able to capture a all kinds of relationships;
    * Averaging bootstrap aggregates reduces the variance of the estimator;
    * There are options (how many trees, how deep, ...), but random forests tend to have great performance **out-of-the-box**.
* This means we have a predictive model that works well with minimal thinking about the underlying problem;
* This makes random forests a great benchmark

<font color = "grey"><i>(You should still, cross-validate to get a reasonable estimate of the performance.)</i></font></small>

Random Forests
========================================================
incremental: true
class: small-code

<small>A model that combines tree-based models with **bootstrap aggregation**.

* Random forests can be easily fit in R too...


```r
library("randomForest")
set.seed(1234)
wh.train <- sample(1:nrow(iris), 100)                       
TrainX   <- iris[wh.train, 1:4]
TrainY   <- iris[wh.train, 5]
TestX    <- iris[-wh.train, 1:4]
TestY    <- iris[-wh.train, 5]

RF        <- randomForest(TrainX, TrainY, ntree = 1000)
PredY     <- predict(RF, TestX)
Confusion <- table(observed  = TestY, predicted = PredY)
Confusion
```

```
            predicted
observed     setosa versicolor virginica
  setosa         18          0         0
  versicolor      0         17         1
  virginica       0          1        13
```

* Only 2 classification mistakes out of 50 in this example;
* ...but you should really use e.g., 10-fold cross-validation.

</small>

Random Forests
========================================================
incremental: true
class: small-code

<small>A model that combines tree-based models with **bootstrap aggregation**.

* A random forest is a great predictive model requiring little (if any) tuning.
* However, they are harder to interpret... forest for the trees.
* A helpful measure in understanding how a random forest came to its decision is the **variable importance**:


```r
importance(RF)
```

```
             MeanDecreaseGini
Sepal.Length         8.624053
Sepal.Width          1.218334
Petal.Length        29.714474
Petal.Width         26.268546
```

</small>

Random Forests
========================================================
incremental: true
class: small-code

<small>**Variable importance** can also be visualized:


```r
varImpPlot(RF)
```

<img src="TreeRegressionCRMV-figure/unnamed-chunk-77-1.png" alt="plot of chunk unnamed-chunk-77" width="1008px" />

* Apparently our classification model relies heavily on petal measurements, and much less so sepal measurements.

</small>

Random Forests
========================================================

<br><br>

<center><b><font size = 10>Questions?</font></b></center>
